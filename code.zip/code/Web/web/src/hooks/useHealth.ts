import { useState } from 'react';
import { healthService } from '../services/healthService';
import { healthHistoryService } from '../services/healthHistoryService';
import { HealthData } from '../types/health';

export function useHealth(userId: string) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [report, setReport] = useState<HealthData | null>(null);

  const submitHealthData = async (data: {
    height: number;
    weight: number;
    food: string;
    calories: number;
    water: number;
    activity: string;
  }) => {
    setLoading(true);
    setError(null);

    try {
      await healthService.setUserInfo(userId, data.height, data.weight);
      await healthService.logFood(userId, data.food, data.calories);
      await healthService.logWater(userId, data.water);
      await healthService.logActivity(userId, data.activity);

      // Save to local history
      healthHistoryService.saveEntry(userId, data);

      const newReport = await healthService.getReport(userId);
      setReport(newReport);
    } catch (err) {
      setError('Failed to submit health data. Please try again.');
      console.error('Health submission error:', err);
    } finally {
      setLoading(false);
    }
  };

  return {
    loading,
    error,
    report,
    submitHealthData,
  };
}