import { useState, useCallback } from 'react';
import { chatService } from '../services/chatService';
import { healthHistoryService } from '../services/healthHistoryService';
import { ChatMessage, MemberData } from '../types/chat';
import { HealthHistory } from '../types/health';

export function useHealthChat(memberData: MemberData, userId: string) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const createPrompt = (message: string, healthHistory: HealthHistory | null) => {
    if (!healthHistory) return message;

    return `
      Based on my health data from ${new Date(healthHistory.timestamp).toLocaleString()}:
      - Height: ${healthHistory.height} cm
      - Weight: ${healthHistory.weight} kg
      - Last meal: ${healthHistory.food} (${healthHistory.calories} calories)
      - Water intake: ${healthHistory.water} glasses
      - Activity: ${healthHistory.activity}

      My question is: ${message}

      Please provide personalized health advice considering this information.
    `.trim();
  };

  const sendMessage = useCallback(async (text: string) => {
    setIsLoading(true);
    setError(null);

    // Add user message immediately
    const userMessage: ChatMessage = {
      text,
      isUser: true,
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, userMessage]);

    try {
      // Get last health entry
      const healthHistory = healthHistoryService.getLastEntry(userId);
      
      // Create enhanced prompt with health history
      const enhancedPrompt = createPrompt(text, healthHistory);
      
      // Send to chat service with member data
      const response = await chatService.sendMessage(enhancedPrompt, memberData);
      
      // Add bot response
      const botMessage: ChatMessage = {
        text: response.message,
        isUser: false,
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, botMessage]);
    } catch (err) {
      setError('Failed to send message. Please try again.');
      console.error('Chat error:', err);
    } finally {
      setIsLoading(false);
    }
  }, [memberData, userId]);

  return {
    messages,
    isLoading,
    error,
    sendMessage,
  };
}