import { MessageSquare, User } from 'lucide-react';

interface ChatMessageProps {
  text: string;
  isUser: boolean;
}

export function ChatMessage({ text, isUser }: ChatMessageProps) {
  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-4`}>
      <div className={`flex items-start max-w-[80%] ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
        <div className={`flex-shrink-0 ${isUser ? 'ml-2' : 'mr-2'}`}>
          {isUser ? (
            <User className="h-8 w-8 rounded-full bg-blue-100 p-1 text-blue-600" />
          ) : (
            <MessageSquare className="h-8 w-8 rounded-full bg-gray-100 p-1 text-gray-600" />
          )}
        </div>
        <div
          className={`px-4 py-2 rounded-lg ${
            isUser
              ? 'bg-blue-600 text-white'
              : 'bg-gray-100 text-gray-900'
          }`}
        >
          {text}
        </div>
      </div>
    </div>
  );
}