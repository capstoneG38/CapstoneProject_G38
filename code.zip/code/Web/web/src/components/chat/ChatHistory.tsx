import { ChatMessage as ChatMessageType } from '../../types/chat';
import { ChatMessage } from './ChatMessage';

interface ChatHistoryProps {
  messages: ChatMessageType[];
}

export function ChatHistory({ messages }: ChatHistoryProps) {
  return (
    <div className="h-96 overflow-y-auto mb-4 p-4 bg-gray-50 rounded-lg">
      {messages.map((msg, index) => (
        <ChatMessage
          key={index}
          text={msg.text}
          isUser={msg.isUser}
        />
      ))}
    </div>
  );
}