import { useState, FormEvent } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { healthApi } from '../../lib/api';
import { Apple, Droplets, Activity, Scale } from 'lucide-react';

export function HealthForm() {
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    height: '',
    weight: '',
    food: '',
    calories: '',
    water: '',
    activity: '',
  });
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [report, setReport] = useState<{ water_needed?: string; food_needed?: string }>({});

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setLoading(true);
    setMessage('');

    try {
      // Set user info
      await healthApi.setUserInfo(
        user.uid,
        Number(formData.height),
        Number(formData.weight)
      );

      // Log food
      if (formData.food && formData.calories) {
        await healthApi.logFood(
          user.uid,
          formData.food,
          Number(formData.calories)
        );
      }

      // Log water
      if (formData.water) {
        await healthApi.logWater(
          user.uid,
          Number(formData.water)
        );
      }

      // Log activity
      if (formData.activity) {
        await healthApi.logActivity(
          user.uid,
          formData.activity
        );
      }

      // Get updated report
      const healthReport = await healthApi.getReport(user.uid);
      setReport({
        water_needed: healthReport.water_needed,
        food_needed: healthReport.food_needed
      });

      setMessage('Data saved successfully!');
      setFormData({
        height: '',
        weight: '',
        food: '',
        calories: '',
        water: '',
        activity: '',
      });
    } catch (error) {
      setMessage('Error saving data. Please try again.');
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <div className="space-y-6">
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Existing form fields */}
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
          <div>
            <label htmlFor="height" className="block text-sm font-medium text-gray-700">
              Height (cm)
            </label>
            <div className="mt-1 relative">
              <input
                type="number"
                name="height"
                id="height"
                value={formData.height}
                onChange={handleChange}
                className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                required
              />
              <Scale className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
          </div>

          <div>
            <label htmlFor="weight" className="block text-sm font-medium text-gray-700">
              Weight (kg)
            </label>
            <div className="mt-1 relative">
              <input
                type="number"
                name="weight"
                id="weight"
                value={formData.weight}
                onChange={handleChange}
                className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                required
              />
              <Scale className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
          </div>

          <div>
            <label htmlFor="food" className="block text-sm font-medium text-gray-700">
              Food
            </label>
            <div className="mt-1 relative">
              <input
                type="text"
                name="food"
                id="food"
                value={formData.food}
                onChange={handleChange}
                className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                required
              />
              <Apple className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
          </div>

          <div>
            <label htmlFor="calories" className="block text-sm font-medium text-gray-700">
              Calories
            </label>
            <div className="mt-1 relative">
              <input
                type="number"
                name="calories"
                id="calories"
                value={formData.calories}
                onChange={handleChange}
                className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                required
              />
              <Activity className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
          </div>

          <div>
            <label htmlFor="water" className="block text-sm font-medium text-gray-700">
              Water (glasses)
            </label>
            <div className="mt-1 relative">
              <input
                type="number"
                name="water"
                id="water"
                value={formData.water}
                onChange={handleChange}
                className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                required
              />
              <Droplets className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
          </div>

          <div>
            <label htmlFor="activity" className="block text-sm font-medium text-gray-700">
              Physical Activity
            </label>
            <div className="mt-1 relative">
              <input
                type="text"
                name="activity"
                id="activity"
                value={formData.activity}
                onChange={handleChange}
                className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                required
              />
              <Activity className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
          </div>
        </div>

        {message && (
          <div className={`text-sm ${message.includes('Error') ? 'text-red-500' : 'text-green-500'}`}>
            {message}
          </div>
        )}

        <div>
          <button
            type="submit"
            disabled={loading}
            className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
          >
            {loading ? 'Saving...' : 'Save Health Data'}
          </button>
        </div>
      </form>

      {report.water_needed || report.food_needed ? (
        <div className="mt-6 p-4 bg-blue-50 rounded-lg">
          <h3 className="text-lg font-medium text-blue-900 mb-2">Health Report</h3>
          {report.water_needed && (
            <p className="text-blue-700">Water needed: {report.water_needed}</p>
          )}
          {report.food_needed && (
            <p className="text-blue-700">Food recommendation: {report.food_needed}</p>
          )}
        </div>
      ) : null}
    </div>
  );
}