import { useAuth } from '../hooks/useAuth';
import { useHealthChat } from '../hooks/useHealthChat';
import { ChatHistory } from '../components/chat/ChatHistory';
import { ChatInput } from '../components/chat/ChatInput';
import { healthHistoryService } from '../services/healthHistoryService';

export default function Dashboard() {
  const { user } = useAuth();
  
  // In a real app, you'd get this data from user profile
  const memberData = {
    name: user?.displayName || 'Anonymous',
    dob: '1990-01-01T00:00:00.000Z', // Example date
    gender: 'Not specified',
    diseases: [],
  };

  const { messages, isLoading, error, sendMessage } = useHealthChat(memberData, user?.uid || '');
  const lastEntry = user ? healthHistoryService.getLastEntry(user.uid) : null;

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white shadow rounded-lg">
        <div className="p-6">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Health Assistant</h2>
          
          {lastEntry && (
            <div className="mb-4 p-4 bg-blue-50 rounded-lg">
              <h3 className="text-sm font-medium text-blue-900 mb-2">Last Health Entry</h3>
              <p className="text-sm text-blue-700">
                Last updated: {new Date(lastEntry.timestamp).toLocaleString()}
              </p>
            </div>
          )}
          
          <ChatHistory messages={messages} />
          
          {error && (
            <div className="mb-4 text-sm text-red-600">
              {error}
            </div>
          )}

          <ChatInput
            onSendMessage={sendMessage}
            isLoading={isLoading}
            placeholder="Ask about your health, diet, or exercise recommendations..."
          />
        </div>
      </div>
    </div>
  );
}