import { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { useHealth } from '../hooks/useHealth';
import { Scale, Apple, Droplets, Activity } from 'lucide-react';

export default function FormPage() {
  const { user } = useAuth();
  const { loading, error, report, submitHealthData } = useHealth(user?.uid || '');
  const [formData, setFormData] = useState({
    height: '',
    weight: '',
    food: '',
    calories: '',
    water: '',
    activity: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    await submitHealthData({
      height: Number(formData.height),
      weight: Number(formData.weight),
      food: formData.food,
      calories: Number(formData.calories),
      water: Number(formData.water),
      activity: formData.activity,
    });

    // Clear form after successful submission
    if (!error) {
      setFormData({
        height: '',
        weight: '',
        food: '',
        calories: '',
        water: '',
        activity: '',
      });
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  if (!user) {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="bg-white shadow rounded-lg p-6">
          <p className="text-center text-gray-600">Please log in to access the health form.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white shadow rounded-lg">
        <div className="p-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Health Tracker</h2>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
              <div>
                <label htmlFor="height" className="block text-sm font-medium text-gray-700">
                  Height (cm)
                </label>
                <div className="mt-1 relative">
                  <input
                    type="number"
                    name="height"
                    id="height"
                    value={formData.height}
                    onChange={handleChange}
                    className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                    required
                  />
                  <Scale className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
                </div>
              </div>

              <div>
                <label htmlFor="weight" className="block text-sm font-medium text-gray-700">
                  Weight (kg)
                </label>
                <div className="mt-1 relative">
                  <input
                    type="number"
                    name="weight"
                    id="weight"
                    value={formData.weight}
                    onChange={handleChange}
                    className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                    required
                  />
                  <Scale className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
                </div>
              </div>

              <div>
                <label htmlFor="food" className="block text-sm font-medium text-gray-700">
                  Food
                </label>
                <div className="mt-1 relative">
                  <input
                    type="text"
                    name="food"
                    id="food"
                    value={formData.food}
                    onChange={handleChange}
                    className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                    required
                  />
                  <Apple className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
                </div>
              </div>

              <div>
                <label htmlFor="calories" className="block text-sm font-medium text-gray-700">
                  Calories
                </label>
                <div className="mt-1 relative">
                  <input
                    type="number"
                    name="calories"
                    id="calories"
                    value={formData.calories}
                    onChange={handleChange}
                    className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                    required
                  />
                  <Activity className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
                </div>
              </div>

              <div>
                <label htmlFor="water" className="block text-sm font-medium text-gray-700">
                  Water (glasses)
                </label>
                <div className="mt-1 relative">
                  <input
                    type="number"
                    name="water"
                    id="water"
                    value={formData.water}
                    onChange={handleChange}
                    className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                    required
                  />
                  <Droplets className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
                </div>
              </div>

              <div>
                <label htmlFor="activity" className="block text-sm font-medium text-gray-700">
                  Physical Activity
                </label>
                <div className="mt-1 relative">
                  <input
                    type="text"
                    name="activity"
                    id="activity"
                    value={formData.activity}
                    onChange={handleChange}
                    className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                    required
                  />
                  <Activity className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
                </div>
              </div>
            </div>

            {error && (
              <div className="text-sm text-red-600">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
            >
              {loading ? 'Submitting...' : 'Submit Health Data'}
            </button>
          </form>

          {report && (
            <div className="mt-6 p-4 bg-blue-50 rounded-lg">
              <h3 className="text-lg font-medium text-blue-900 mb-2">Health Report</h3>
              {report.water_needed && (
                <p className="text-blue-700">Water needed: {report.water_needed}</p>
              )}
              {report.food_needed && (
                <p className="text-blue-700">Food recommendation: {report.food_needed}</p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}