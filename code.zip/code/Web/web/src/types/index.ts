export interface ApiResponse {
  message: string;
}

export interface HealthData {
  water_needed: number | string;
  food_needed: string;
  food_entries: Array<{
    food: string;
    calories: number;
    date: string;
  }>;
  water_intake: Array<{
    glasses: number;
    date: string;
  }>;
  physical_activities: Array<{
    activity: string;
    date: string;
  }>;
  weight_entries: Array<{
    weight: number;
    date: string;
  }>;
}