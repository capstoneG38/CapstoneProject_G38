export interface HealthHistory {
  height: number;
  weight: number;
  food: string;
  calories: number;
  water: number;
  activity: string;
  timestamp: string;
}

export interface HealthData {
  water_needed: string | number;
  food_needed: string;
  food_entries: Array<{
    food: string;
    calories: number;
    date: string;
  }>;
  water_intake: Array<{
    glasses: number;
    date: string;
  }>;
  physical_activities: Array<{
    activity: string;
    date: string;
  }>;
  weight_entries: Array<{
    weight: number;
    date: string;
  }>;
}