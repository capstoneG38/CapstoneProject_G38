export interface MemberData {
  name: string;
  dob: string;
  gender: string;
  diseases: string[];
}

export interface ChatResponse {
  message: string;
}

export interface ChatMessage {
  text: string;
  isUser: boolean;
  timestamp: Date;
}