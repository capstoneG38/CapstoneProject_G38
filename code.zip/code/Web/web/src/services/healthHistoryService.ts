import { HealthHistory } from '../types/health';

// Service to manage health data history in localStorage
export const healthHistoryService = {
  saveEntry(userId: string, data: any) {
    try {
      localStorage.setItem(`health_${userId}`, JSON.stringify({
        ...data,
        timestamp: new Date().toISOString()
      }));
    } catch (error) {
      console.error('Error saving health history:', error);
    }
  },

  getLastEntry(userId: string): HealthHistory | null {
    try {
      const data = localStorage.getItem(`health_${userId}`);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      console.error('Error getting health history:', error);
      return null;
    }
  }
};