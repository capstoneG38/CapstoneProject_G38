import { ChatResponse, MemberData } from '../types/chat';

const API_BASE_URL = 'http://localhost:8088';

export const chatService = {
  async sendMessage(message: string, memberData: MemberData): Promise<ChatResponse> {
    try {
      const response = await fetch(`${API_BASE_URL}/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message,
          memberName: memberData.name,
          dob: memberData.dob,
          gender: memberData.gender,
          diseases: memberData.diseases,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || 'Failed to send message');
      }

      return response.json();
    } catch (error) {
      if (error instanceof Error) {
        console.error('Error sending message:', error.message);
        throw new Error(error.message);
      }
      console.error('Error sending message:', error);
      throw new Error('Failed to send message');
    }
  },
};