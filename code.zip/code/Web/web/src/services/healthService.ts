import { HealthData } from '../types';

const API_BASE_URL = 'http://localhost:8088';

export const healthService = {
  async setUserInfo(userId: string, height: number, weight: number) {
    try {
      const response = await fetch(`${API_BASE_URL}/api/user`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: userId, height, weight }),
      });

      if (!response.ok) {
        throw new Error('Failed to set user info');
      }

      return response.json();
    } catch (error) {
      console.error('Error setting user info:', error);
      throw error;
    }
  },

  async logFood(userId: string, food: string, calories: number) {
    try {
      const response = await fetch(`${API_BASE_URL}/api/food`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          user_id: userId, 
          food, 
          calories,
          date: new Date().toISOString()
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to log food');
      }

      return response.json();
    } catch (error) {
      console.error('Error logging food:', error);
      throw error;
    }
  },

  async logWater(userId: string, glasses: number) {
    try {
      const response = await fetch(`${API_BASE_URL}/api/water`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          user_id: userId, 
          glasses,
          date: new Date().toISOString()
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to log water intake');
      }

      return response.json();
    } catch (error) {
      console.error('Error logging water:', error);
      throw error;
    }
  },

  async logActivity(userId: string, activity: string) {
    try {
      const response = await fetch(`${API_BASE_URL}/api/activity`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          user_id: userId, 
          activity,
          date: new Date().toISOString()
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to log activity');
      }

      return response.json();
    } catch (error) {
      console.error('Error logging activity:', error);
      throw error;
    }
  },

  async getReport(userId: string): Promise<HealthData> {
    try {
      const response = await fetch(`${API_BASE_URL}/api/report?user_id=${userId}`);
      
      if (!response.ok) {
        throw new Error('Failed to get health report');
      }

      return response.json();
    } catch (error) {
      console.error('Error getting report:', error);
      throw error;
    }
  },
};