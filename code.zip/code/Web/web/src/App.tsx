import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './hooks/useAuth';
import { LoadingSpinner } from './components/ui/LoadingSpinner';
import AuthPage from './pages/AuthPage';
import Dashboard from './pages/Dashboard';
import FormPage from './pages/FormPage';
import Layout from './components/Layout';

function App() {
  const { user, loading } = useAuth();

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <Router>
      <Routes>
        <Route path="/auth" element={!user ? <AuthPage /> : <Navigate to="/dashboard" />} />
        <Route path="/dashboard" element={
          <Layout>
            {user ? <Dashboard /> : <Navigate to="/auth" />}
          </Layout>
        } />
        <Route path="/form" element={
          <Layout>
            {user ? <FormPage /> : <Navigate to="/auth" />}
          </Layout>
        } />
        <Route path="/" element={<Navigate to={user ? "/dashboard" : "/auth"} />} />
      </Routes>
    </Router>
  );
}

export default App;