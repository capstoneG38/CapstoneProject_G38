import { initializeApp, getApps } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyA54maeSVxmtjgS4YNVFYopyAyhYm8UgIo",
  authDomain: "buzzy-screen.firebaseapp.com",
  projectId: "buzzy-screen",
  storageBucket: "buzzy-screen.firebasestorage.app",
  messagingSenderId: "747314760089",
  appId: "1:747314760089:web:117c1d704f7260b843eb08",
  measurementId: "G-BRKQFY6DRG"
};

// Initialize Firebase only if no apps exist
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];
export const auth = getAuth(app);
export const db = getFirestore(app);