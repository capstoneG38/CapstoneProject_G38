import { HealthData, ApiResponse } from '../types';

const API_BASE_URL = 'http://localhost:8088';

export const healthApi = {
  async setUserInfo(userId: string, height: number, weight: number): Promise<ApiResponse> {
    const response = await fetch(`${API_BASE_URL}/api/user`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ user_id: userId, height, weight }),
    });
    return response.json();
  },

  async logFood(userId: string, food: string, calories: number): Promise<ApiResponse> {
    const response = await fetch(`${API_BASE_URL}/api/food`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        user_id: userId, 
        food, 
        calories,
        date: new Date().toISOString()
      }),
    });
    return response.json();
  },

  async logWater(userId: string, glasses: number): Promise<ApiResponse> {
    const response = await fetch(`${API_BASE_URL}/api/water`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        user_id: userId, 
        glasses,
        date: new Date().toISOString()
      }),
    });
    return response.json();
  },

  async logActivity(userId: string, activity: string): Promise<ApiResponse> {
    const response = await fetch(`${API_BASE_URL}/api/activity`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        user_id: userId, 
        activity,
        date: new Date().toISOString()
      }),
    });
    return response.json();
  },

  async logWeight(userId: string, weight: number): Promise<ApiResponse> {
    const response = await fetch(`${API_BASE_URL}/api/weight`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        user_id: userId, 
        weight,
        date: new Date().toISOString()
      }),
    });
    return response.json();
  },

  async getReport(userId: string): Promise<HealthData> {
    const response = await fetch(`${API_BASE_URL}/api/report?user_id=${userId}`);
    return response.json();
  },
};