from dotenv import load_dotenv
import os
import google.generativeai as genai
import requests

preLoadData = """You are a Food Dite Expert assistant so u should assit them 
if incase they need any help and if u see something is seriour u tall which doctor to meet
and get conseltence. Provide a diagnosis and recommendations based on the following input.
Format your response as follows:
- Name: [Patient's Name]
- Assumed Issues: [List of possible issues]
- Perivous Food Intake Details: []
- Most Common Solution: [Suggested solution]
- Give Indian Food Recamendation : [LIST of Food]
- Suject Execies: []
- If Required, Recommended Medication: [List of medications]
- Focus: Lifestyle and dietary recommendations, particularly Indian foods.

give the following input in TXT/HTML format"""

class MedicalChatbot:
    def __init__(self):
        print("""Hi! This is BeeBotix, the creator of this code.
Just a friendly reminder to create a .env file and set your GOOGLE_API_KEY environment variable before using this program.
Thank you!
================= Happy Chatting =================""")
        load_dotenv()  # Load environment variables from .env file
        api_key = os.getenv("GOOGLE_API_KEY")

        if not api_key:
            print("Invalid/No API Key in .env file")
            return

        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel("gemini-pro")
        self.chat = self.model.start_chat(history=[])

    def check_internet_connection(self):
        try:
            requests.get("https://www.google.com", timeout=1)
            return True
        except requests.ConnectionError:
            return False

    def get_medical_response(self, member):
        name = member.get('name')
        age = member.get('age')
        gender = member.get('gender')
        diseases = member.get('diseases')
        message = member.get('message')

        # Prepare the full prompt
        full_prompt = preLoadData + "\n" + f"Patient Name: {name}, Age: {age}, Gender: {gender}, Diseases: {diseases}, Message: {message}"

        if not self.check_internet_connection():
            return {"message": "Sorry, can't connect to the internet. Please check your connection."}

        response = self.chat.send_message(full_prompt, stream=True)

        # Check the safety ratings
        for chunk in response:
            if hasattr(chunk, 'safety_ratings'):
                print(f"Safety Ratings: {chunk.safety_ratings}")  # Log safety ratings
            if hasattr(chunk, 'text'):
                return {"message": " ".join(chunk.text for chunk in response)}

        return {"message": "No valid response received from the AI model."}

