from flask import Flask, request, jsonify
from flask_cors import CORS
from datetime import datetime
from gemini_chatbot import MedicalChatbot as GeminiChatbot
import os
import google.generativeai as genai
from dotenv import load_dotenv

# Initialize the Flask app and CORS
app = Flask(__name__)
CORS(app)

# Dummy database (in-memory) for multiple users
users_data = {}

# Initialize the chatbot
load_dotenv()  # Load environment variables from .env file
api_key = os.getenv("GOOGLE_API_KEY")

if not api_key:
    print("Invalid/No API Key in .env file")

genai.configure(api_key=api_key)
chatbot = GeminiChatbot()

@app.route('/api/user', methods=['POST'])
def set_user_info():
    data = request.json
    user_id = data.get('user_id')  # Expecting a user ID or name
    height = data.get('height')
    weight = data.get('weight')

    if user_id not in users_data:
        users_data[user_id] = {
            'food_entries': [],
            'water_intake': [],
            'physical_activities': [],
            'weight_entries': [],
            'height': float(height) if height is not None else None,
            'weight': float(weight) if weight is not None else None,
        }
    else:
        users_data[user_id]['height'] = float(height) if height is not None else None
        users_data[user_id]['weight'] = float(weight) if weight is not None else None

    return jsonify({"message": f"User info set for {user_id} successfully!"}), 201

@app.route('/api/food', methods=['POST'])
def log_food():
    data = request.json
    user_id = data.get('user_id')
    
    if user_id not in users_data:
        return jsonify({"message": "Unknown user!"}), 404

    calories = data.get('calories')
    users_data[user_id]['food_entries'].append({
        'food': data['food'],
        'calories': calories,
        'date': data.get('date', datetime.now().isoformat())
    })
    return jsonify({"message": "Food logged successfully!"}), 201

@app.route('/api/water', methods=['POST'])
def log_water():
    data = request.json
    user_id = data.get('user_id')
    
    if user_id not in users_data:
        return jsonify({"message": "Unknown user!"}), 404

    users_data[user_id]['water_intake'].append(data)
    return jsonify({"message": "Water intake logged successfully!"}), 201

@app.route('/api/activity', methods=['POST'])
def log_activity():
    data = request.json
    user_id = data.get('user_id')
    
    if user_id not in users_data:
        return jsonify({"message": "Unknown user!"}), 404

    users_data[user_id]['physical_activities'].append(data)
    return jsonify({"message": "Activity logged successfully!"}), 201

@app.route('/api/weight', methods=['POST'])
def log_weight():
    data = request.json
    user_id = data.get('user_id')

    if user_id not in users_data:
        return jsonify({"message": "Unknown user!"}), 404

    users_data[user_id]['weight_entries'].append({
        'weight': data['weight'],
        'date': data.get('date', datetime.now().isoformat())
    })
    return jsonify({"message": "Weight logged successfully!"}), 201

@app.route('/api/report', methods=['GET'])
def get_report():
    user_id = request.args.get('user_id')

    if user_id not in users_data:
        return jsonify({"message": "Unknown user!"}), 404

    water_needed = calculate_hydration_goal(users_data[user_id].get('weight'))
    food_needed = calculate_food_intake(users_data[user_id].get('weight'), users_data[user_id].get('height'))
    
    return jsonify({
        "water_needed": water_needed,
        "food_needed": food_needed,
        "food_entries": users_data[user_id]['food_entries'],
        "water_intake": users_data[user_id]['water_intake'],
        "physical_activities": users_data[user_id]['physical_activities'],
        "weight_entries": users_data[user_id]['weight_entries'],
    }), 200
@app.route('/chat', methods=['POST'])
def chat():
    # Get data from the request
    data = request.get_json()

    # Extract fields from the request
    message = data.get('message', '')
    name = data.get('memberName')
    dob = data.get('dob')
    gender = data.get('gender')
    diseases = data.get('diseases')

    # Print received data for debugging
    print("Received member data:", data)

    # Calculate age from DOB if necessary
    age = calculate_age(dob) if dob else None

    # Create a member dictionary
    member = {
        'name': name,
        'age': age,
        'gender': gender,
        'diseases': diseases,
        'message': message
    }

    # Get the response from the chatbot
    try:
        response = chatbot.get_medical_response(member)
        return jsonify(response)
    except Exception as e:
        print(f"Error in generating response: {e}")
        return jsonify({"message": "There was an error processing your request. Please try again later."}), 500

def calculate_age(dob):
    from datetime import datetime
    if dob:
        dob_date = datetime.strptime(dob, '%Y-%m-%dT%H:%M:%S.%fZ')  # Adjust format to match the incoming data
        today = datetime.today()
        age = today.year - dob_date.year - ((today.month, today.day) < (dob_date.month, dob_date.day))
        return age
    return None

def calculate_hydration_goal(weight):
    if weight is not None:
        try:
            return round(float(weight) * 0.033, 2)
        except ValueError:
            return "Invalid weight value."
    return "Weight not provided."

def calculate_food_intake(weight, height):
    if weight is not None and height is not None:
        bmi = weight / ((height / 100) ** 2)
        if bmi < 18.5:
            return "Increase food intake."
        elif 18.5 <= bmi < 24.9:
            return "Maintain current food intake."
        else:
            return "Reduce food intake."
    return "Height or weight not provided."

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8088)
